pm clear --user 0 com.android.packageinstaller
rm -r /data/system/package_cache/*
